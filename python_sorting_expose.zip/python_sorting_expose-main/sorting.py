import time
import random
import matplotlib.pyplot as plt
import numpy as np

a = int(input("Podaj ile liczb chcesz porównać: "))

lista1 = []
lista2 = []
lista3 = []

for i in range(a):
    randomnum = (random.randint(0,10))
    lista1.append(randomnum)
    lista2.append(randomnum)
    lista3.append(randomnum)


def sortowanie_babelkowe(lista):
    n = len(lista)
    
    while n > 1:
        zamien = False
        for l in range(0, n-1):
            if lista[l] > lista[l+1]:
                lista[l], lista[l+1] = lista[l+1], lista[l]
                zamien = True
                
        n -= 1
        if zamien == False: break        
    return lista

def sortowanie_wybieranie(y):
    for i, n in enumerate(y):
        j, m = min(enumerate(y[i:]), key = lambda a: a[1])
        y[j + i], y[i] = n, m
    return y


print("Porównanie wybierania")
time1 = time.time()
sortowanie_wybieranie(lista1)
time2 = time.time()
print("Czas w ms: ", time2 - time1)
first_check = time2 - time1
time3 = time.time()
print("Prównanie bąbelkowe")
sortowanie_babelkowe(lista2)
time4 = time.time()
print("Czas w ms:", time4 - time3)
second_check = time4 - time3
print("Porównanie natywne python")
time5 = time.time()
lista3.sort()
time6 = time.time()
print("Czas w ms: ", time6 - time5)
third_check = time6 - time5
X =["b","w","s"]
Y = [first_check, second_check, third_check]
plt.bar(X,Y)
plt.grid(True)
plt.show()
